//
//  UIFont+LTMLineHeight.h
//  LTM
//
//  Created by 汪潇翔 on 30/09/2016.
//  Copyright © 2016 wangxiaoxiang. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UIFont (LTMLineHeight)

- (CGFloat)ltm_lineHeight;

@end
